\-- The Hazardless Project --



If installed through AIRDrop, ignore this message, and skip to Step 2.



1. If you installed this on GameBanana, make sure to move this folder of the mod into "C:\\Users\\(Your User)\\AppData\\Sonic3AIR\\Mods"! Replace (Your User) with your username on your local computer, otherwise this mod won't show up. 
2. Make sure to put this at the top of your list if you have other level layout mods! Putting this below will not allow the Zones to be emptied out, which can discard the changes! 
3. When you go to Options > Mods, click on "The Hazardless Project" to customize it if wanted. Full is the default option and clears the Badniks, hazards, and overall death-points of all Zones. The option "Sonic 3" does exactly that but cuts off at Launch Base Zone Act 2, and from forth, all Zones are normal. The last option, "Sonic \& Knuckles", does the opposite, starting from Mushroom Hill Zone Act 1, the Zones ahead are cleared, but leaves the Sonic 3 half untouched.



Other than that, have fun breezing through the Zones!

