\-- The Hazardless Project --



A simple Sonic the Hedgehog 3 A.I.R. mod that removes all spikes, Badniks, and main hazards in general from the base game, or anything that will tremendously slow you down.

It does not remove all hazards, only the most common ones / major ones, others have been left in because they are either necessary for game progression or makes the game less detailed, such as the lava in Lava Reef Zone.

This does not require the most updated version of Sonic 3 A.I.R., rather, any of them that use "leveldata.json" inside (mod) > rawdata > leveldata.json.

I recommend extracting the main .zip folder you opened to get to this file, then putting it inside your mods folder (for Windows, C:\\Users\\(Your User)\\AppData\\Roaming\\Sonic3AIR\\mods) rather than leaving it just as an uncompressed .zip file, but it works. Compatible with the AIRdrop mod manager tool.

