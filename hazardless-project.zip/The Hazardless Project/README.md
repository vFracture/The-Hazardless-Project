\-- The Hazardless Project --



If installed through AIRDrop, ignore this message, and skip to Step 2.



1. If you installed this on GameBanana, make sure to move this folder of the mod into "C:\\Users\\(Your User)\\AppData\\Sonic3AIR\\Mods" for Windows! Replace (Your User) with your username on your local computer, otherwise this mod won't show up.
2. Make sure to put this at the top of your list if you have other level layout mods! Putting this below will not allow the Zones to be emptied out, which can discard the changes!

